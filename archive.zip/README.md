# Queue Bot
for people that don't have geometry dash on computer and need a queue bot